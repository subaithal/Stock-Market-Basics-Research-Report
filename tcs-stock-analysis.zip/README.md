# TCS Stock Analysis (Task 2)
Single-file website: HTML + CSS + JavaScript. No backend, no API keys.

Live site: https://YOUR-USERNAME.github.io/tcs-stock-analysis/

For educational purposes only. Not investment advice.
